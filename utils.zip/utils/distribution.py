from numpy.core.fromnumeric import transpose
import numpy as np
import pandas as pd

def get_df_info(df, thr=0):
    '''
    Returns dataframe column info as a dataframe
    df: received dataframe
    df_info - returned dataframe

    '''
    df_info = pd.DataFrame(index= df.columns)

    df_info["dtype"] = df[df.columns].dtypes.apply(lambda t: t.name)
    df_info["nunique"] = df.nunique()

    nans = df.isna().sum() / df.shape[0]
    mask1 = df.isna().any(axis=0)
    nans[mask1] = nans[mask1].round(3)
    nans[~mask1] = -1
    trash = nans.copy()
    nans[mask1] = nans[mask1].round(3)
    nans[~mask1] = -1
    df_info["nan"] = nans

    zeros = (df == 0).sum() / df.shape[0]
    mask2 = (df == 0).any(axis=0)
    trash[(~mask1) & mask2] = zeros
    trash[(~mask1) & (~mask2)] += zeros
    zeros[mask2] = zeros[mask2].round(3)
    zeros[~mask2] = -1
    df_info["zero"] = zeros

    empty = (df == '').sum() / df.shape[0]
    mask3 = (df == '').any(axis=0)
    trash[~mask1 & ~mask2 & mask3] = empty
    trash[(mask1 | mask2) & mask3] += empty
    empty[mask3] = empty[mask3].round(3)
    empty[~mask3] = -1
    df_info["empty_str"] = empty

    #function receives a column name and finds the most frequent value(nan excluded)
    #returns tuple (highest frequency, most frequent value)
    def find_max(col):
        s = df[col].value_counts(normalize=True, dropna=True)
        return (round(s.max(), 3), s.idxmax())

    df_info["vc_max"] = df.columns.map(lambda col: find_max(col))

    #function receives a column name and finds 2 examples
    #if unable to find 1 or 2 examples nan is returnes instead of the example
    def find_examples(col):
        s = df[col]
        s = s.dropna().drop_duplicates()
        if s.empty:
            return (np.nan, np.nan)
        if s.shape[0] == 1:
            return (s.sample(), np.nan)
        return s.sample(n = 2, replace=False).values
        #use .values when series of pd objects given
    examples = df.columns.map(lambda col: find_examples(col))
    #returning examples
    df_info["example1"] = examples.map(lambda x: x[0])
    df_info["example2"] = examples.map(lambda x: x[1])
    #df_info["example1"] = df_info['example1'].replace("", "''")
    #df_info["example2"] = df_info['example2'].replace("", "''")
    
    trash_option = df_info.vc_max.apply(lambda x: x[0])
    trash_option[trash_option < thr] = -1
    trash[trash < trash_option] = trash_option
    df_info["trash_score"] = trash.round(3)

    #df_info.trash_score = df_info.trash_score.replace(-1.0, -1)
    return df_info

import numpy as np
from numpy.ma.extras import notmasked_contiguous
import matplotlib.pyplot as plt
import seaborn as sns

def plot_density(df, hue, cols=None, drop_zero=False, max_cat_thr=20):
    '''
    Рисует распределения колонок cols

    cols: отрисовываемые колонки. Если None, то рисуем df.columns (кроме hue)
    '''
    sns.set_context("paper", font_scale=1.6,rc={"font.size":15,"axes.titlesize":20,"axes.labelsize":15})
    if cols == None:
        cols = df.columns
    for col in cols:
        if col == hue:
            continue
        cat_flag = df[col].dropna().drop_duplicates().shape[0] < max_cat_thr
        #check if dtype is number(int or float)
        if np.issubdtype(np.asarray(df[col]).dtype, np.number) and not cat_flag:
            info = df.copy()
            if drop_zero:
                info = info[df[col] != 0]
            fig, ax = plt.subplot_mosaic('abc')
            sns.histplot(multiple='stack', element='step', stat='count')

            for category in df[hue].dropna().drop_duplicates():
                ax['a'].hist(info.loc[df[hue] == category, col], bins=25, alpha=0.8, label=category)
                ax['a'].legend(fontsize=15).set_title(hue)

                sns.boxenplot(data=info, y=col, x=hue, ax=ax['b'], showfliers=False)
                ylim = ax['b'].get_ylim() # remember hte limit of y for boxenplot
                sns.stripplot(data=info.groupby(hue).sample(100), y=col, x=hue, ax=ax['b'], color='black', size=4)
                ax['b'].set_title('no fliers', fontsize=15)
                ax['b'].set(ylim=ylim) # setting the same limit for boxenplot + stripplot
            #prepare data for nans/zeros information

            group_sizes = df.groupby(by=hue).size()
            nans = df[df[col].isna()].groupby(by=hue).size() / group_sizes
            zeros = df[df[col]==0].groupby(by=hue).size() / group_sizes
            new_dataframe = pd.DataFrame()
            # replace "pure zero" with smth < 0 for example -1*max(new_dataframe) * 0.05
            # NaN means we got zero fitting elements
            nans = nans.fillna(-0.1)
            zeros = zeros.fillna(-0.1)
            nans[nans == -0.1] = -0.05*max(nans.max(), zeros.max())
            zeros[zeros == -0.1] = -0.05*max(nans.max(), zeros.max())
            #creating a dataframe having necessary columns(read about sns.barplot with hue)
            new_dataframe1,  new_dataframe2 = pd.DataFrame(), pd.DataFrame()
            new_dataframe1[hue] = df[hue].dropna().drop_duplicates()
            new_dataframe2[hue] = new_dataframe1[hue].copy()
            new_dataframe1['val'] = zeros
            new_dataframe2['val'] = nans
            new_dataframe1['zero/nan'] = '0'
            new_dataframe2['zero/nan'] = 'nan'

            sns.barplot(pd.concat([new_dataframe1,  new_dataframe2]), x='zero/nan',
                          y='val', hue=hue, edgecolor='black')
            ax["c"].axhline(0, color='black', ls='--')
            ax["c"].grid(True, axis='y')

            fig.suptitle(col + ' vs ' + hue, fontsize=20)
            fig.set_size_inches(15, 5)
            fig.tight_layout()

            plt.show()
            print("#"*100)
        # categorial
        if cat_flag:
            #preparing data
            info = df.copy() #not to spoil the dataframe given
            mask= info[col].isna()
            info[col] = info[col].astype(str)
            info.loc[mask,  col] = '<NaN>'
            info.loc[info[col] == '', col] = '<Empty>'
            info = info.sort_values(by=col)

            sns.countplot(info, x=col, hue=hue, edgecolor='black')
            fig, ax = plt.gcf(), plt.gca()
            ax.tick_params('x', rotation=90)
            fig.set_size_inches(15, 5)
            fig.suptitle(col + ' vs ' + hue, fontsize=20)
            plt.show()
            print("#"*100)
